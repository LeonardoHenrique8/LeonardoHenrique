import { Component } from '@angular/core';
import { Game } from './game';
import { GameService } from './game.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  newGame: Game = {} as Game
  myGames: Game[] = []
  visitanteName: string = ''
  mandanteName: string = ''

  constructor(private gameService: GameService) {}

  ngOnInit() {
  }

  save(myForm: any) {
    this.gameService.save(this.newGame).subscribe(
      () => {
        myForm.reset()
        this.newGame = {} as Game
        alert('Jogo cadastrado!')
      }
    )
  }

  loadData() {
    this.gameService.findGames(this.visitanteName,this.mandanteName).subscribe(
      data => this.myGames = data
    )
  }

  searchGame(myForm: any) {
    this.loadData()
    myForm.reset()
    this.visitanteName = ''
    this.mandanteName = ''
  }

  removeGame(gameId: number) {
    this.gameService.deleteGame(gameId).subscribe(
      () => this.loadData()
    )
  }
}
