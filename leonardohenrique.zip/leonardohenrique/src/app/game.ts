export interface Game {

  golsTimeVisitante: Number
  golsTimeMandante: Number
  timeVisitante: String
  timeMandante: String
  id: number

}